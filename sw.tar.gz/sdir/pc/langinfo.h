/* langinfo.h replacement for MS-Windows build.  */
#ifndef LANGINFO_H
#define LANGINFO_H

#define CODESET 1

extern char *nl_langinfo (int);

#endif
